package com.srkr.users.exception;

public class PatientNotFoundException extends RuntimeException{
    public PatientNotFoundException(Long id){
        super("Could not found the user with id "+ id);
    }
}
